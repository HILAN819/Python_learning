zeros = [0] * 5
# print(zeros)
char = "Hello world"
print(list(char))
pack = list(char)
f, g, *other = pack
print(other) 