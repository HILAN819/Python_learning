even_numbers = []
for i in range(100, 401):
    if i % 2 == 0:
        even_numbers.append(i)
print(even_numbers)
