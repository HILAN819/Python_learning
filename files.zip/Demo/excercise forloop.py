s = 0
n = int(input("Enter any number: "))
for y in range(1, n+1, 1):
    s += y

print("\n")
print("Sum is: ", s)