y = input("Y: ")
x = input("X: ")
answer = int(y) ** int(x)
print(f"Answer: {answer}")


class Name:
    def name(self):
        print("My name is Hillary", self)
