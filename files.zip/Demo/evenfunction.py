def even(n):
    if n % 2 == 0:
        return "n is an even number"

    return "n is an odd number"


print(even(14))
