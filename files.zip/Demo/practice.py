word = "Masquarading"
for i in word:
    if i == "u":
        y = (word.find("u"))
        print(word[0:y])
    else:
        print(word[-1:5])