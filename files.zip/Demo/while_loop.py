#command = ""
#while command != "quit":
#    command = input(">")
#    print('ECHO', command)

# A loop to generate the first 10 natural numbers
x = 1
while x <= 10:
    print(x)
    x += 1
