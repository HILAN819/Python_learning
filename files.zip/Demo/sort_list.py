numbers = [4, 53, 23, 7, 8]
numbers.sort(reverse = True)
# print(numbers)
print(sorted(numbers))