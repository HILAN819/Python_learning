length = int(input("Length: "))
width = int(input("Width: "))

if length == width:
    print("This is a square.")
else:
    print("This is a rectangle.")
