from math import pi

r = float(input("Radius: "))
Area = pi * (r**2)
print("The area of the circle with radius" + str(r) + " is: " + str(Area))
