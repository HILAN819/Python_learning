password_index = { 'Account 1' : ['Username: mrbooleanswag','Password: askjdkljfgsdfg'],
'Account 2' : ['Username: Lexington','Password: kfsdjgfdg']
}
print ("The current list of accounts has %s accounts in it." % (len(password_index)))
print(password_index)

# accuser = raw_input("What account would you like to access? ")      
# account 1
# print  "The information to %s is %s" % (accuser,    password_index[accuser.lower()]) "The information to account 1 is ['Username: mrbooleanswag','Password: askjdkljfgsdfg']
# exit = raw_input("Press enter to exit...")