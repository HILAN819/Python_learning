browsing_session = []
browsing_session.append(1)
browsing_session.append(2)
browsing_session.append(3)
browsing_session.append(4)
print(browsing_session)
browsing_session.pop(-1)

if not browsing_session:
    browsing_session[-1]

