import math
#print(round(23.56))
#print(abs(-34.43))

#print(math.ceil(3.4))
x = 12%5
print(x)
#print(round(x))
print(math.ceil(23.2))
print(math.fabs(27.867))
y = input("")
print(y)