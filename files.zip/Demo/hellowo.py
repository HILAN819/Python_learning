word = "westgate"
print(word[::])