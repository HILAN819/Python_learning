file = open('file_path', 'w')
file.write('Hello world')
file.close()