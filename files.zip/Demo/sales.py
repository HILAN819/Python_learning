def calc_tax():
    pass


def calc_shipping():

    print("pass")
# import sys
# print(sys.path)
# from pathlib import Path
# path = Path("ecommerce/__init__.py")
# print(path.exists())
