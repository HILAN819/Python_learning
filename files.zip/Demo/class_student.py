class Student:
#     # A simple class
    """A simple example class"""
    stu_class = 'V'
    stu_roll_no = 12
    stu_name = "David"
    def messg(self):
            return 'New Session will start soon.'
    
    # def messg(self):
    #     return 'New session will return soon.'

# student1 = ('Kevin', 3453, 13, 45)
# student1()

# class School:
#     def __init__(self, *subjects):
#         self.subjects = list(subjects)

# class Subject:
    
#     def __add__(self, other):
#         return School(self, other)
# F1, F2 = Subject(), Subject()
# F1 + F2