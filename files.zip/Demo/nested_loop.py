for x in range(5):
    for y in range(2):
        print(f"({x}, {y})")

for x in "this is my kingdom":
    print(x) 