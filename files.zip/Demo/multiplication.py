n = 2
for i in range(1, 10, 1):
    p = n * i
    print(p)
