menu = []
class Restaurant: 
   
    def __init__(self, items, orders, table):
        self.items = {}
        self.orders = []
        self.table = []
    
    def add_item_to_menu(self, item):
        self.item = item
        print(menu.append(item))
        
    def table_reservation(self, table):
        price
